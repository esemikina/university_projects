var triangleX = 100
var triangleY = 100
var triangleX1 = 200
var triangleY1 = 100
var triangleX2 = 150
var triangleY2 = 40

var base = {
  x: 100,
  y: 100,
  x1: 100,
  y1: 100 
};


function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 250, 255);
  
  //base
  fill(255, 102, 178);
  rect(base.x, base.y, base.x1, base.y1);
  base.x = base.x + 1;

  
  //roof
  fill(255, 102, 178);
  fill(204, 0, 102);
  triangle(triangleX, triangleY, triangleX1, triangleY1, triangleX2, triangleY2);
  
  
  //door
  fill(204, 0, 102);
  rect(135, 150, 28, 50);
  
  
  //door knob
  fill(255, 255, 0);
  ellipse(140, 175, 5,5);
  
  
  //windows
  fill(255, 255, 255)
  rect(110, 116, 30, 29);
  fill(255, 255, 255)
  rect(160, 116, 30, 29);
  
}
