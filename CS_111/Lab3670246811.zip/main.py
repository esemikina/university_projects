######################################################
# Project: Lab3
# UIN: 670246811
# URL to your repl.it project: https://repl.it/@ysemik2/Lab3670246811
######################################################\

# import the module containing the turtle and screen definitions
import turtle       

#create a new Turtle by invoking the constructor method in the turtle package;  assign to variable t
t = turtle.Turtle() 
# get a reference to the screen object holding the turtle; assign to variable s
s = t.getscreen()

# define the size of the screen 
s.setup(width=500, height=500)

# give it a background color
s.bgcolor("silver")


# when testing, set tracer to 0 to turn off screen updating
# when you do set it to 0, you need to call the "update" method on the screen object at the end to paint the screen
# s.tracer(0)

# hide the turtle so we don't see its shape
t.hideturtle()

# position the turtle and write some text
t.penup()
t.goto(-200,200)
t.write("Lab 3 - <670246811>",move=False, align='left', font=('Arial', 24, 'normal'))


# position the turtle so we have room to draw some big triangles
t.goto(-200,0)

# variables for angle and side_length

angle = 120
side_length = 10
 




# set color and add commands to draw a filled turtle of a specific color
# leave the turtle at the appropriate starting place for the next triangle
angle = 120
side_length = 10
t.fillcolor("black")
t.begin_fill()
for i in range(3):
  t.pendown()
  t.forward(side_length)
  t.left(angle)
t.end_fill()
t.penup()
t.forward(side_length)
t.end_fill()

angle01 = 120
side_length01 = side_length * 2
t.pencolor("DeepSkyBlue")
t.fillcolor("DeepSkyBlue")
t.begin_fill()
for i in range(3):
  t.pendown()
  t.forward(side_length01)
  t.left(angle01)
t.end_fill()
t.penup()
t.forward(side_length01)
t.end_fill()

angle02 = 120
side_length02 = side_length01 * 2
t.pencolor("blue")
t.fillcolor("blue")
t.begin_fill()
for i in range(3):
  t.pendown()
  t.forward(side_length02)
  t.left(angle02)
t.end_fill()
t.penup()
t.forward(side_length02)
t.end_fill()

angle03 = 120
side_length03 = side_length02 * 2
t.pencolor("DarkOrange")
t.fillcolor("DarkOrange")
t.begin_fill()
for i in range(3):
  t.pendown()
  t.forward(side_length03)
  t.left(angle03)
t.end_fill()
t.penup()
t.forward(side_length03)
t.end_fill()

angle04 = 120
side_length04 = side_length03 * 2
t.pencolor("yellow")
t.fillcolor("yellow")
t.begin_fill()
for i in range(3):
  t.pendown()
  t.forward(side_length04)
  t.left(angle04)
t.end_fill()
t.penup()
t.forward(side_length04)
t.end_fill()








# set a new color, increase your side_length and draw another triangle;
#  do this for a total of 5 triangles of increasing size and differing colors
















