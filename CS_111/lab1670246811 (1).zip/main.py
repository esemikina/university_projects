######################################################
# Project: Lab_1
# UIN: 670246811
# URL to your repl.it project: https://repl.it/@ysemik2/lab1template
######################################################
print("Yelizaveta Semikina")
print("Pasta")
print("Konner Gorak")