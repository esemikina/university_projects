let img;
let heart;

function preload() {
   img = loadImage('corgi-min.jpg');
   heart = loadImage('unnamed.png');
}

function setup() {
  createCanvas(600, 400);
 
}

function draw() {
  background(220);
  image(img, 0, 0, 600, 400);
  image(heart, mouseX, mouseY, 120, 100);
  
    
}