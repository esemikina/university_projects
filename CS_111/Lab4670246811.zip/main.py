######################################################
# Assignment: Lab 4
# UIN: 670246811
# URL to your Repl.it: https://repl.it/@ysemik2/Lab4670246811
######################################################


# DONE: import the turtle package

import turtle              
wn = turtle.Screen()        
t = turtle.Turtle()      

# DONE: create a new turtle and assign to variable t1
t1 = turtle.Turtle() 

# DONE: write the commands to draw a rectangle 75 x 25 (filled or unfilled, your choice)
t1.penup()
t1.goto(-150,150)
lenght = 75
width = 25 
# reminder to test and save often


# DONE: create a function named draw_rectangle and move the above commands into it
def draw_rectangle(x, y, lenght, width, color, heading, pensize):
  t1.pensize(pensize)
  t1.fillcolor(color)
  t1.begin_fill() 
  t1.goto(x, y)
  t1.setheading(heading)
  t1.pendown()
  t1.forward(lenght)
  t1.right(90)
  t1.forward(width)
  t1.right(90)
  t1.forward(lenght)
  t1.right(90)
  t1.forward(width)
  t1.end_fill()

# DONE: uncomment the following line to test your function
# color = "red"
# draw_rectangle(lenght, width, color)




# DONE: update the function to accept parameters for length and width



# DONE:  uncomment the following line to test your function
# draw_rectangle (50, 100)


# reminder to save often


# DONE: update your function to accept a parameter for color


# DONE: uncomment the line below to test your updated function;
#       you should see a red square
#draw_rectangle (50, 50, "red")




# DONE: update your function to accept x and y coordinates;
#       you'll need to use the 'goto" method in your function
#       the x and y coordinates will be the first two parameters



# DONE: uncomment the following line to test your function;
#draw_rectangle (-25, -50, 25, 100, "blue")


# DONE: update your function to accept a parameter for heading and pensize
#       these should be at the end of the parameter list


# DONE: uncomment the following lines to test your function
#draw_rectangle (50, -50, 75, 15, "green", 45, 10)
#draw_rectangle (0, 0, 30, 75, "orange", 0, 4)
#draw_rectangle (100, 100, 25, 25, "purple", 75, 1)


# DONE:  use the turtle "write" method to write your UIN and name 
#        write them at x = -100, y = 100

#t1.goto(-100,100)
#t1.write("Lab 4 - <670246811>",move=False, align='left', font=('Arial', 15, 'normal'))