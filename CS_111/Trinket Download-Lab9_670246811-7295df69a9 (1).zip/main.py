######################################################
# Assignment: Lab 9
# UIN: 670246811
# URL to your assignment: https://trinket.io/library/trinkets/7295df69a9
######################################################
#!/bin/python3

from vars import *  # this will expose all the variables in vars.py

file_string = ""
results = []

results.append(len(some_numbers))
results.append(sum(some_numbers)) 
results.append(len(student["courses"]))
results.append(student["birthdate"])

blk_cars = 0
sil_4d_cars = 0
largest_inventory_number = 0

for car in towed_cars:
  if 'color' in car:
    if car['color'] == "BLK":
      blk_cars += 1

for car in towed_cars:
  if 'color' in car and 'style' in car:
    if car['color'] == "SIL" and car['style'] == "4D":
      sil_4d_cars += 1
      
for car in towed_cars :
  if 'inventory_number' in car:
    if int(car['inventory_number']) > largest_inventory_number:
      largest_inventory_number = int(car['inventory_number'])
      
results.append(blk_cars)
results.append(sil_4d_cars)
results.append(largest_inventory_number)
sorted_ABC_list = []
# create separate list
for title in course_catalog.keys():
  sorted_ABC_list.append(title)
# sort title list alphabetically
sorted_ABC_list.sort()

# len of second title
results.append(len(course_catalog[sorted_ABC_list[1]]))


target_key = ""
result_string = ""
# print out courses
for i in range(len(sorted_ABC_list)):
  result_string += sorted_ABC_list[i] + ": " + course_catalog[sorted_ABC_list[i]] + "\n"

results.append(result_string);



for i in range(len(results)): 
    if i != len(results)-1 :
      file_string += str(i+1) + ". " + str(results[i]) + "\n"
    else :
      file_string += str(results[i]) + "\n"
    
fo = open("lab9_670246811_answers.txt", "w")
fo.write(file_string)
fo.close()




  
  